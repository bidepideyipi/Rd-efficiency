# 研发效能工具（map-sql-generator）

本机研发效能套件（Spring Boot），当前包含：

1. **Excel → SQL**：将「数据迁移中间表映射关系」Excel 生成 Oracle `SELECT`（一表一 `{表名}.sql`）
2. **库 ↔ Excel 对比**：OceanBase（Oracle 模式）基表结构 vs 映射 Excel 左侧目标栏位；类型不同标黄改写，库多则追加，Excel 多则标红
3. **代码扫描 dealcode**：扫描工程目录下 `.fc`，提取 `paramList` 中的 `dealcode` / `dealmsg`，输出 CSV

要求：**JDK 8+**（工程按 1.8 编译；Spring Boot 2.7.18）。

## 启动 Web

```bash
cd map-sql-generator
mvn spring-boot:run
```

浏览器打开：http://localhost:8080

左侧菜单切换工具。

---

## 工具 1：Excel → SQL

1. 配置 SQL 文件输出目录（默认 `~/mig/sql/map`）
2. 上传 Excel（`.xlsx`）
3. 勾选目标表 → 生成

### 配置

`src/main/resources/application.yml`：

- `mig.default-export-dir`：页面默认输出目录
- `mig.datasources`：OceanBase Oracle 模式数据源列表（`id` / `jdbcUrl` / `schema` / `enabled`）

### 生成规则摘要

- 规则说明非空且像 SQL → 优先使用
- 类型不同 → 自动转换（如 `VARCHAR2`→`NUMBER`）
- 字符型源长 > 目标长 → `SUBSTR`
- 「库表关联条件」解析进 `WHERE`，并支持 `LEFT JOIN` / `INNER JOIN`（含 `select * from … inner join …` 同格写法）
- 时间条件保留 `{{beginTm}}` / `{{endTm}}` / `{{tmColumn}}`

跳板机：**sqlplus** 导出 `.dat` + `.ctl`（`export_*.sh`），**sqlldr** 装载（`load_*.sh`）。编辑 `scripts/export-job.conf`（含 `tgtConnect`）。说明见 `scripts/README.md` 与 `docs/map-sql-generator-design.md` §7。

---

## 工具 2：库 ↔ Excel 对比

1. 在 `application.yml` 配置 `mig.datasources`，将目标库 `enabled: true`
2. 打开「库 ↔ Excel 对比」：选择数据源 → 上传 V0.4 映射 Excel → 下载标注结果
3. 规则（以库为准，对齐 Excel **左侧目标栏位**）：
   - 数据类型/长度不同 → 改写并 **黄色** 标注
   - 库有、Excel 无 → **追加**行（备注 `【DB新增】`）
   - Excel 有、库无 → **红色** 标注，备注提醒人工删除
4. 汇总见结果文件中的 `_DB_EXCEL_DIFF` Sheet

API：`GET /api/datasources`、`POST /api/datasources/test`、`POST /api/excel-db-diff`

---

## 工具 3：数据标准扫描

按 SQLite 数标规则扫描 OceanBase（Oracle 模式）基表，生成 ALTER SQL。

规则类型：

- `TYPE`：按数据类型族匹配，如 `CHAR` → `VARCHAR2({n})`，`CLOB` → `VARCHAR2(400)`（`{n}`/`{p}`/`{s}` 取自当前列）
- `COLUMN`：字段名全匹配（忽略大小写），如 `AMOUNT` → `NUMBER(22,2)`

CHAR / CLOB / NUMBER 等不能直接 `MODIFY` 时，生成**四步重建**：

1. `ALTER TABLE ... ADD (col_MIGTMP ...)`
2. `COMMENT ON COLUMN ...`（复制原 comment）
3. `UPDATE ... SET col_MIGTMP = ...`（拷贝原始值）
4. `DROP COLUMN` 旧字段 + `RENAME COLUMN` 临时字段改回原名

### 配置

```yaml
mig:
  standard-db-path: ${user.home}/mig/data-standard.db
```

首次启动自动建表并写入默认规则（CHAR / CLOB / AMOUNT）。

### API

- `GET/POST/PUT/DELETE /api/standard/rules`
- `POST /api/standard/scan` — `{ "datasourceId": "..." }` → 命中列表 + SQL 文本
- `POST /api/standard/scan/export` — 下载 `.sql`

---

## 工具 4：代码扫描 dealcode

扫描指定工程根目录下所有 `.fc` 文件：

- 优先解析 `<Key>paramList</Key>` 后的内层 `<Arg>` 文本
- 否则用正则配对 `["dealcode","..."]` 与 `["dealmsg","..."]`
- 相对根目录：**一级目录 = 服务名**，**二级目录 = 模块名**（更深层级忽略）

### 页面用法

1. 填写工程根目录（可用仓库内 `example/` 验证）
2. 检测目录 → 开始扫描
3. 预览 CSV → 下载 `dealcode-scan.csv`（UTF-8 BOM，便于 Excel）

### CSV 结构

明细区：

```text
服务名,模块名,dealcode,dealmsg,文件名,行号
```

空行后为总览（按 dealcode 字母升序）：

```text
总览
dealcode,数量
A00000,1
A000000,2
FIBC009,1
```

样例（根目录为 `example`）：

| 相对路径 | 服务名 | 模块名 |
|----------|--------|--------|
| `demo1.fc` | （空） | （空） |
| `BEPS/BEPSBusiCheckService/scene/.../x.fc` | `BEPS` | `BEPSBusiCheckService` |

### API

- `GET /api/scan/dealcode/config` — 默认工程目录
- `POST /api/scan/dealcode/check-dir` — `{ "path": "..." }`
- `POST /api/scan/dealcode` — `{ "projectDir": "..." }` → JSON + CSV 预览
- `POST /api/scan/dealcode/export` — 同上，返回 CSV 附件

### 配置

```yaml
mig:
  scan:
    default-project-dir: ""   # 可选，预填页面工程根目录
```
